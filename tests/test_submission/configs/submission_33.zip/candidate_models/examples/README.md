# Brain-Score-Models Examples

Basic examples to get you up and running with your model.

[model-activations](model-activations.ipynb): retrieve model internal activations

[score-model](score-model.ipynb): score a model on Brain-Score
